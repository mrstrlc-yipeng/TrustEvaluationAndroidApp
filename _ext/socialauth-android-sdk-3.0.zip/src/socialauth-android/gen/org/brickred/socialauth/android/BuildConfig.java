/** Automatically generated file. DO NOT MODIFY */
package org.brickred.socialauth.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}