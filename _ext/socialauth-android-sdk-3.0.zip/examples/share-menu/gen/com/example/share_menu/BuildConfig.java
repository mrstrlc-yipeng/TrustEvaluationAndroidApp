/** Automatically generated file. DO NOT MODIFY */
package com.example.share_menu;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}