/** Automatically generated file. DO NOT MODIFY */
package com.facebook.scrumptious;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}